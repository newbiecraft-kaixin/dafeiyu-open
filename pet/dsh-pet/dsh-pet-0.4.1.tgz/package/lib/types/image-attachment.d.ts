/**
 * 对话图片入参的解析：把线上 JSON 的 `attachment` 变成附件服务可直接接收的字节。
 * 不做 IO、不碰附件服务——落盘与权威校验（解码真实性、像素上限）在路由层，本模块只负责
 * 形状、媒体类型白名单与 base64 规范化。
 * @module dsh-pet/src/host/image-attachment
 */
/** 图片媒体类型白名单，与宿主附件服务接受的集合一致。 */
export type PetImageMediaType = 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
/** 一张已落盘的图片：只声明 pet 用到的字段，不引 @deepseek-ai/dsh-attachment 的类型包。 */
export interface PetImageRef {
    readonly attachmentId: string;
    readonly mediaType: PetImageMediaType;
    readonly bytes: number;
    readonly width: number;
    readonly height: number;
}
/** 定位一张已落盘图片所需的最小信息：对象路径只由 attachmentId 决定。 */
export interface PetImageLocator {
    readonly attachmentId: string;
}
/** 附件服务的最小形状：DSH 宿主提供，独立模式缺失。 */
export interface PetImageSink {
    /** 部署级单图字节上限；缺失视为不设限（服务内部仍会权威校验）。 */
    readonly imageLimits?: {
        readonly maxImageBytes?: number;
    };
    /** 校验并持久化一批图片，返回与入参同序的引用。 */
    saveImages(inputs: readonly {
        data: Uint8Array;
        mediaType: PetImageMediaType;
    }[]): Promise<readonly PetImageRef[]>;
    /** 宿主文件后端上的绝对路径；非文件后端不提供此方法（取图端点据此回 404）。 */
    imageHostPath?(ref: PetImageLocator): string | undefined;
}
/** 解析结论；失败时 message 直接作为 bad-request 的文案。 */
export type ParsedImage = {
    readonly ok: true;
    readonly mediaType: PetImageMediaType;
    readonly bytes: Uint8Array;
} | {
    readonly ok: false;
    readonly message: string;
};
/**
 * 解析请求体里的 `attachment`。
 *
 * @param raw - 未经校验的原始值。
 * @returns 规范 base64 解出的字节与媒体类型；失败时给出可直接下发的文案。
 */
export declare function parseImageAttachment(raw: unknown): ParsedImage;
